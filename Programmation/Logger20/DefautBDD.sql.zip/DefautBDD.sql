-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Sam 11 Février 2012 à 16:31
-- Version du serveur: 5.1.58
-- Version de PHP: 5.3.9-1~dotdeb.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `remi100756`
--

-- --------------------------------------------------------

--
-- Structure de la table `logger`
--

CREATE TABLE IF NOT EXISTS `logger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `altitude` double NOT NULL,
  `vith` double NOT NULL,
  `vitv` double NOT NULL,
  `tempout` double NOT NULL,
  `tempin` double NOT NULL,
  `temphyg` double NOT NULL,
  `hyg` double NOT NULL,
  `pressout` double NOT NULL,
  `pressin` double NOT NULL,
  `gpsx` double NOT NULL,
  `gpsy` double NOT NULL,
  `gpsaltitude` double NOT NULL,
  `CH4` double NOT NULL,
  `CO2` double NOT NULL,
  `GyrX` double NOT NULL,
  `GyrY` double NOT NULL,
  `GyrZ` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `logger`
--

